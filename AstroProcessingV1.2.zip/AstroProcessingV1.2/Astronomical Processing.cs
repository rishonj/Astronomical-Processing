﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AstroProcessingV1._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static int max = 24; //
        public static int[] number_array = new int[max];

        # region Utilities
        
        //Displays the array data
        private void Display()
        {
            listBoxNumbers.Items.Clear();

            foreach (int num in number_array)
            {
                listBoxNumbers.Items.Add(num);
            }
        }
        
        //PF: The array is filled with random integers to simulate the data stream (numbers between 10 and 99).
        private void FillArray()
        {
            Random rand = new Random();
            for (int i = 0; i < number_array.Length; i++)
            {
                number_array[i] = rand.Next(10, 99);
            }
        }
        
        //Fills the array with random integers
        private void BtnFillArray_Click(object sender, EventArgs e)
        {
            FillArray();
            Display();
            textBoxInput.Focus();
            toolStripStatus.Text = "Array filled with random integers";
        }

        //Displays the selected item in the text box
        private void listBoxNumbers_Click(object sender, EventArgs e)
        {
            if (listBoxNumbers.SelectedIndex != -1)
            {
                string currentItem = listBoxNumbers.SelectedItem.ToString();
                int numIndex = listBoxNumbers.FindString(currentItem);
                textBoxInput.Text = number_array[numIndex].ToString();
                textBoxInput.Focus();
            }
            else
                toolStripStatus.Text = "No task selected";
        }

        //Limits text box input length to two digits (10 - 99) and prevents non-numeric input
        private void textBoxInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            textBoxInput.MaxLength = 2;
        }

        #endregion

        #region AddEditDelete
        //Allows data to be added to the array
        private void BtnAdd_Click(object sender, EventArgs e)
        {
             if (!string.IsNullOrEmpty(textBoxInput.Text))
             {
                  for (int i = 0; i < max; i++)
                  {
                       if (number_array[i] == 0)
                       {
                            number_array[i] = int.Parse(textBoxInput.Text);
                            textBoxInput.Clear();
                            break;
                       }
                       else if (Array.Exists(number_array, element => element != 0) && (i == 23))
                       {
                            toolStripStatus.Text = "Array is full";
                            textBoxInput.Clear();
                            break;
                       }
                  }
                        Display();
             }
             else
             {
                    toolStripStatus.Text = "Text box is empty"; //PF:The program must generate an error message if the text box is empty.
             }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (listBoxNumbers.SelectedIndex != -1)
            {
                DialogResult delNum = MessageBox.Show("Are you sure you wish to remove the selected item?", "Delete Confirmation",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (delNum == DialogResult.Yes)
                {
                    number_array[listBoxNumbers.SelectedIndex] = 0;
                    toolStripStatus.Text = "Item deleted";
                    textBoxInput.Clear();
                }
            }
            else
            {
                toolStripStatus.Text = "Nothing selected";//PF:The program must generate an error message if the text box is empty.
            }
            textBoxInput.Focus();
            Display();
        }
        private void BtnEdit_Click(object sender, EventArgs e)
        {
            int Selected_Index = listBoxNumbers.SelectedIndex;
            if (!string.IsNullOrEmpty(textBoxInput.Text))
            {
                if (Selected_Index != -1)//Checks whether an index is selected or if the textbox is empty
                {
                    DialogResult editItem = MessageBox.Show("Are you sure you wish to edit the selected item?", "Edit Confirmation",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (editItem == DialogResult.Yes)
                    {
                        number_array[Selected_Index] = int.Parse(textBoxInput.Text);//Adds the edited item to the array
                        textBoxInput.Clear();
                        Display();
                        toolStripStatus.Text = "Item edited";
                    }
                }
                else
                {
                    toolStripStatus.Text = "Please select an item to be edited.";
                }
            }
            else
            {
                toolStripStatus.Text = "Text box is empty";//PF:The program must generate an error message if the text box is empty.
            }
            textBoxInput.Focus();
        }

        #endregion

        #region SortSearch
        //CR: There are buttons that can sort the data.

        //PF: The sort method must be coded using the Bubble Sort algorithm.

        //Sorts the data in ascending order, calls BubbleSort() method
        private void BtnBubbleSort_Click(object sender, EventArgs e)
        {
            BubbleSort();
        }
        private void BubbleSort()
        {
            int temp;
            for (int outer = 0; outer < number_array.Length - 1; outer++)
            {
                for (int inner = 0; inner < number_array.Length - 1; inner++)
                {
                    if (number_array[inner] > number_array[inner + 1])
                    {
                        temp = number_array[inner + 1];
                        number_array[inner + 1] = number_array[inner];
                        number_array[inner] = temp;
                    }
                }
            }
            Display();
            toolStripStatus.Text = "Items sorted in ascending order";
        }

        //CR: There are buttons that can search the data.
        //PF: The search method must be coded using the Binary Search algorithm.
        //PF: A single text box is provided for the search input.
        //Searches for specified item
        private void BtnBinarySearch_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBoxInput.Text))
            {
                MessageBox.Show("Binary search may not work on unsorted data. For accurate results please sort data prior to searching.");
                int low = 0;
                int high = number_array.Length;
                int mid = 0;
                string target = textBoxInput.Text;
                int num_target = int.Parse(target);
                if (!string.IsNullOrEmpty(textBoxInput.Text))
                {
                    while (low <= high)
                    {

                        mid = (low + high) / 2;
                        if (number_array[mid] < num_target)
                        {
                            low = mid + 1;
                        }
                        else if (number_array[mid] > num_target)
                        {
                            high = mid - 1;
                        }
                        else
                        {
                            //PF: The program must generate a message if the search is successful.
                            toolStripStatus.Text = "Item " + number_array[mid] + " found at Index " + (Array.IndexOf(number_array, num_target) + 1);
                            listBoxNumbers.SelectedIndex = mid;
                            textBoxInput.Clear();
                            break;
                        }
                    }
                }

                if (number_array[mid] != num_target)
                {
                    //PF: The program must generate an error message if the search is not successful.
                    toolStripStatus.Text = "Not found";
                    textBoxInput.Clear();
                }
            }
            else
                toolStripStatus.Text = "Text box is empty";
        }
        private void BtnSequentialSearch_Click(object sender, EventArgs e)
        {
            bool found = false;
            int target = int.Parse(textBoxInput.Text);


            for(int i = 0; i < number_array.Length; i++)
            {
                if (number_array[i] == target)
                {
                    found = true;
                    toolStripStatus.Text = "Item " + target + " found at index " + (i+1);
                    textBoxInput.Focus();
                    textBoxInput.Clear();
                    listBoxNumbers.SelectedIndex = i;

                    break;
                }
                
            }
            if(found == false)
            {
                toolStripStatus.Text = "Item not found";
                textBoxInput.Clear();
            }
            
        }

        #endregion

        #region ModeAverageRangeMid

        private void BtnAverage_Click(object sender, EventArgs e)
        {
            int sum = 0;
            textBoxMaths.Clear();
            foreach(int num in number_array)
            {
                sum = sum + num;
            }

            int average = sum / number_array.Length;
            textBoxMaths.Text = average.ToString();
            
            
        }

        private void BtnRange_Click(object sender, EventArgs e)
        {
            int max = 0;
            int min = 100;
            textBoxMaths.Clear();
            for (int i = 0; i < number_array.Length; i++)
            {
                if (number_array[i] <= min)
                    min = number_array[i];
                if (number_array[i] >= max)
                    max = number_array[i];
            }

            int range = max - min;
            textBoxMaths.Text = range.ToString();
            
        }

        private void BtnMode_Click(object sender, EventArgs e)
        {
            textBoxMaths.Clear();
            int element;
            int frequency = 1;
            int mode = 0;
            int counter;
            for (int i = 0; i < number_array.Length; i++)
            {
                counter = 0;
                element = number_array[i];//Assign current array element to temp var
                for (int j = 0; j < number_array.Length; j++)//Nested for loop to check how many times temp var occurs
                {
                    if (element == number_array[j])
                    {
                        counter++;//increments counter according to how many times temp var occurs (mode)
                    }
                }
                if (counter >= frequency)//Assigns counter's value to frequency and assigns the mode as the this element
                {
                    frequency = counter;
                    mode = element;
                    
                }
            }
            listBoxNumbers.SelectedItem = mode;
            textBoxMaths.Text = "The mode is element " + mode + " with frequency " + frequency;
            
        }
        private void BtnMidExtreme_Click(object sender, EventArgs e)
        {
            int max = 0;
            int min = 100;
            textBoxMaths.Clear();
            for (int i = 0; i < number_array.Length; i++)
            {
                if (number_array[i] <= min)
                    min = number_array[i];
                if (number_array[i] >= max)
                    max = number_array[i];
            }

            int midExtreme = (max + min) / 2;

            if (number_array.Contains(midExtreme))
            {
                listBoxNumbers.SelectedItem = midExtreme;
            }
            textBoxMaths.Text = midExtreme.ToString();
            
        }

        #endregion

        
    }
}
