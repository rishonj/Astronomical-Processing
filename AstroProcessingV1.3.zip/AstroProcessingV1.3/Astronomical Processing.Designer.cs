﻿
namespace AstroProcessingV1._2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listBoxNumbers = new System.Windows.Forms.ListBox();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.textBoxInput = new System.Windows.Forms.TextBox();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnDelete = new System.Windows.Forms.Button();
            this.BtnEdit = new System.Windows.Forms.Button();
            this.BtnBubbleSort = new System.Windows.Forms.Button();
            this.BtnBinarySearch = new System.Windows.Forms.Button();
            this.BtnFillArray = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnMidExtreme = new System.Windows.Forms.Button();
            this.BtnMode = new System.Windows.Forms.Button();
            this.BtnAverage = new System.Windows.Forms.Button();
            this.BtnRange = new System.Windows.Forms.Button();
            this.BtnSequentialSearch = new System.Windows.Forms.Button();
            this.textBoxMode = new System.Windows.Forms.TextBox();
            this.toolTipMode = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipMidExtreme = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipAverage = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipRange = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipAdd = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipDelete = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipEdit = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipFill = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipBinarySearch = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipBubbleSort = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipSeqSearch = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipInput = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipListBox = new System.Windows.Forms.ToolTip(this.components);
            this.listBoxHours = new System.Windows.Forms.ListBox();
            this.textBoxAverage = new System.Windows.Forms.TextBox();
            this.textBoxMidExtreme = new System.Windows.Forms.TextBox();
            this.textBoxRange = new System.Windows.Forms.TextBox();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBoxNumbers
            // 
            this.listBoxNumbers.FormattingEnabled = true;
            this.listBoxNumbers.Location = new System.Drawing.Point(63, 110);
            this.listBoxNumbers.Name = "listBoxNumbers";
            this.listBoxNumbers.Size = new System.Drawing.Size(132, 329);
            this.listBoxNumbers.TabIndex = 0;
            this.toolTipListBox.SetToolTip(this.listBoxNumbers, "Neutrino reactions per hour\r\n");
            this.listBoxNumbers.Click += new System.EventHandler(this.listBoxNumbers_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatus});
            this.statusStrip.Location = new System.Drawing.Point(0, 494);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(504, 22);
            this.statusStrip.TabIndex = 1;
            this.statusStrip.Text = "Status";
            // 
            // toolStripStatus
            // 
            this.toolStripStatus.Name = "toolStripStatus";
            this.toolStripStatus.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatus.Text = "Status";
            // 
            // textBoxInput
            // 
            this.textBoxInput.Location = new System.Drawing.Point(63, 46);
            this.textBoxInput.Name = "textBoxInput";
            this.textBoxInput.Size = new System.Drawing.Size(132, 20);
            this.textBoxInput.TabIndex = 2;
            this.toolTipInput.SetToolTip(this.textBoxInput, "Enter numbers to add, edit, delete and search");
            this.textBoxInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxInput_KeyPress);
            // 
            // BtnAdd
            // 
            this.BtnAdd.Location = new System.Drawing.Point(222, 111);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(126, 23);
            this.BtnAdd.TabIndex = 3;
            this.BtnAdd.Text = "Add Data";
            this.toolTipAdd.SetToolTip(this.BtnAdd, "Click to add a number from 10-99");
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnDelete
            // 
            this.BtnDelete.Location = new System.Drawing.Point(354, 110);
            this.BtnDelete.Name = "BtnDelete";
            this.BtnDelete.Size = new System.Drawing.Size(127, 23);
            this.BtnDelete.TabIndex = 4;
            this.BtnDelete.Text = "Delete Data";
            this.toolTipDelete.SetToolTip(this.BtnDelete, "Click to delete selected item");
            this.BtnDelete.UseVisualStyleBackColor = true;
            this.BtnDelete.Click += new System.EventHandler(this.BtnDelete_Click);
            // 
            // BtnEdit
            // 
            this.BtnEdit.Location = new System.Drawing.Point(222, 140);
            this.BtnEdit.Name = "BtnEdit";
            this.BtnEdit.Size = new System.Drawing.Size(126, 23);
            this.BtnEdit.TabIndex = 5;
            this.BtnEdit.Text = "Edit Data";
            this.toolTipEdit.SetToolTip(this.BtnEdit, "Click to edit the selected number");
            this.BtnEdit.UseVisualStyleBackColor = true;
            this.BtnEdit.Click += new System.EventHandler(this.BtnEdit_Click);
            // 
            // BtnBubbleSort
            // 
            this.BtnBubbleSort.Location = new System.Drawing.Point(354, 170);
            this.BtnBubbleSort.Name = "BtnBubbleSort";
            this.BtnBubbleSort.Size = new System.Drawing.Size(127, 23);
            this.BtnBubbleSort.TabIndex = 6;
            this.BtnBubbleSort.Text = "Bubble Sort";
            this.toolTipBubbleSort.SetToolTip(this.BtnBubbleSort, "Click to sort the numbers with \r\na Bubble Sort algorithm");
            this.BtnBubbleSort.UseVisualStyleBackColor = true;
            this.BtnBubbleSort.Click += new System.EventHandler(this.BtnBubbleSort_Click);
            // 
            // BtnBinarySearch
            // 
            this.BtnBinarySearch.Location = new System.Drawing.Point(222, 170);
            this.BtnBinarySearch.Name = "BtnBinarySearch";
            this.BtnBinarySearch.Size = new System.Drawing.Size(126, 23);
            this.BtnBinarySearch.TabIndex = 7;
            this.BtnBinarySearch.Text = "Binary Search";
            this.toolTipBinarySearch.SetToolTip(this.BtnBinarySearch, "Click to search for specified number with \r\na binary search algorithm");
            this.BtnBinarySearch.UseVisualStyleBackColor = true;
            this.BtnBinarySearch.Click += new System.EventHandler(this.BtnBinarySearch_Click);
            // 
            // BtnFillArray
            // 
            this.BtnFillArray.Location = new System.Drawing.Point(354, 139);
            this.BtnFillArray.Name = "BtnFillArray";
            this.BtnFillArray.Size = new System.Drawing.Size(127, 23);
            this.BtnFillArray.TabIndex = 8;
            this.BtnFillArray.Text = "Fill Data";
            this.toolTipFill.SetToolTip(this.BtnFillArray, "Click to fill array with numbers from 10 to 99");
            this.BtnFillArray.UseVisualStyleBackColor = true;
            this.BtnFillArray.Click += new System.EventHandler(this.BtnFillArray_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Neutrion Reactions p/Hour";
            // 
            // BtnMidExtreme
            // 
            this.BtnMidExtreme.Location = new System.Drawing.Point(306, 391);
            this.BtnMidExtreme.Name = "BtnMidExtreme";
            this.BtnMidExtreme.Size = new System.Drawing.Size(81, 23);
            this.BtnMidExtreme.TabIndex = 10;
            this.BtnMidExtreme.Text = "Mid-Extreme";
            this.toolTipMidExtreme.SetToolTip(this.BtnMidExtreme, "Click to calculate the Mid-Extreme");
            this.BtnMidExtreme.UseVisualStyleBackColor = true;
            this.BtnMidExtreme.Click += new System.EventHandler(this.BtnMidExtreme_Click);
            // 
            // BtnMode
            // 
            this.BtnMode.Location = new System.Drawing.Point(222, 336);
            this.BtnMode.Name = "BtnMode";
            this.BtnMode.Size = new System.Drawing.Size(252, 23);
            this.BtnMode.TabIndex = 11;
            this.BtnMode.Text = "Mode";
            this.toolTipMode.SetToolTip(this.BtnMode, "Click to calculate the mode\r\n");
            this.BtnMode.UseVisualStyleBackColor = true;
            this.BtnMode.Click += new System.EventHandler(this.BtnMode_Click);
            // 
            // BtnAverage
            // 
            this.BtnAverage.Location = new System.Drawing.Point(222, 391);
            this.BtnAverage.Name = "BtnAverage";
            this.BtnAverage.Size = new System.Drawing.Size(78, 23);
            this.BtnAverage.TabIndex = 12;
            this.BtnAverage.Text = "Average";
            this.toolTipAverage.SetToolTip(this.BtnAverage, "Click to calculate the average rounded to two decimal places");
            this.BtnAverage.UseVisualStyleBackColor = true;
            this.BtnAverage.Click += new System.EventHandler(this.BtnAverage_Click);
            // 
            // BtnRange
            // 
            this.BtnRange.Location = new System.Drawing.Point(393, 391);
            this.BtnRange.Name = "BtnRange";
            this.BtnRange.Size = new System.Drawing.Size(81, 23);
            this.BtnRange.TabIndex = 13;
            this.BtnRange.Text = "Range";
            this.toolTipRange.SetToolTip(this.BtnRange, "Click to calculate the range");
            this.BtnRange.UseVisualStyleBackColor = true;
            this.BtnRange.Click += new System.EventHandler(this.BtnRange_Click);
            // 
            // BtnSequentialSearch
            // 
            this.BtnSequentialSearch.Location = new System.Drawing.Point(287, 199);
            this.BtnSequentialSearch.Name = "BtnSequentialSearch";
            this.BtnSequentialSearch.Size = new System.Drawing.Size(126, 23);
            this.BtnSequentialSearch.TabIndex = 14;
            this.BtnSequentialSearch.Text = "Sequential Search";
            this.toolTipSeqSearch.SetToolTip(this.BtnSequentialSearch, "Click to searchs for specified number with\r\na sequential search algorithm\r\n");
            this.BtnSequentialSearch.UseVisualStyleBackColor = true;
            this.BtnSequentialSearch.Click += new System.EventHandler(this.BtnSequentialSearch_Click);
            // 
            // textBoxMode
            // 
            this.textBoxMode.Location = new System.Drawing.Point(222, 365);
            this.textBoxMode.Name = "textBoxMode";
            this.textBoxMode.ReadOnly = true;
            this.textBoxMode.Size = new System.Drawing.Size(252, 20);
            this.textBoxMode.TabIndex = 15;
            // 
            // listBoxHours
            // 
            this.listBoxHours.FormattingEnabled = true;
            this.listBoxHours.Location = new System.Drawing.Point(13, 110);
            this.listBoxHours.Name = "listBoxHours";
            this.listBoxHours.Size = new System.Drawing.Size(44, 329);
            this.listBoxHours.TabIndex = 16;
            // 
            // textBoxAverage
            // 
            this.textBoxAverage.Location = new System.Drawing.Point(222, 420);
            this.textBoxAverage.Name = "textBoxAverage";
            this.textBoxAverage.ReadOnly = true;
            this.textBoxAverage.Size = new System.Drawing.Size(78, 20);
            this.textBoxAverage.TabIndex = 17;
            // 
            // textBoxMidExtreme
            // 
            this.textBoxMidExtreme.Location = new System.Drawing.Point(306, 420);
            this.textBoxMidExtreme.Name = "textBoxMidExtreme";
            this.textBoxMidExtreme.ReadOnly = true;
            this.textBoxMidExtreme.Size = new System.Drawing.Size(81, 20);
            this.textBoxMidExtreme.TabIndex = 18;
            // 
            // textBoxRange
            // 
            this.textBoxRange.Location = new System.Drawing.Point(393, 420);
            this.textBoxRange.Name = "textBoxRange";
            this.textBoxRange.ReadOnly = true;
            this.textBoxRange.Size = new System.Drawing.Size(81, 20);
            this.textBoxRange.TabIndex = 19;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 516);
            this.Controls.Add(this.textBoxRange);
            this.Controls.Add(this.textBoxMidExtreme);
            this.Controls.Add(this.textBoxAverage);
            this.Controls.Add(this.listBoxHours);
            this.Controls.Add(this.textBoxMode);
            this.Controls.Add(this.BtnSequentialSearch);
            this.Controls.Add(this.BtnRange);
            this.Controls.Add(this.BtnAverage);
            this.Controls.Add(this.BtnMode);
            this.Controls.Add(this.BtnMidExtreme);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnFillArray);
            this.Controls.Add(this.BtnBinarySearch);
            this.Controls.Add(this.BtnBubbleSort);
            this.Controls.Add(this.BtnEdit);
            this.Controls.Add(this.BtnDelete);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.textBoxInput);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.listBoxNumbers);
            this.Name = "Form1";
            this.Text = "Astronomical Processing";
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxNumbers;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.TextBox textBoxInput;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnDelete;
        private System.Windows.Forms.Button BtnEdit;
        private System.Windows.Forms.Button BtnBubbleSort;
        private System.Windows.Forms.Button BtnBinarySearch;
        private System.Windows.Forms.Button BtnFillArray;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatus;
        private System.Windows.Forms.Button BtnMidExtreme;
        private System.Windows.Forms.Button BtnMode;
        private System.Windows.Forms.Button BtnAverage;
        private System.Windows.Forms.Button BtnRange;
        private System.Windows.Forms.Button BtnSequentialSearch;
        private System.Windows.Forms.TextBox textBoxMode;
        private System.Windows.Forms.ToolTip toolTipMode;
        private System.Windows.Forms.ToolTip toolTipMidExtreme;
        private System.Windows.Forms.ToolTip toolTipAverage;
        private System.Windows.Forms.ToolTip toolTipRange;
        private System.Windows.Forms.ToolTip toolTipInput;
        private System.Windows.Forms.ToolTip toolTipAdd;
        private System.Windows.Forms.ToolTip toolTipDelete;
        private System.Windows.Forms.ToolTip toolTipEdit;
        private System.Windows.Forms.ToolTip toolTipBubbleSort;
        private System.Windows.Forms.ToolTip toolTipBinarySearch;
        private System.Windows.Forms.ToolTip toolTipFill;
        private System.Windows.Forms.ToolTip toolTipSeqSearch;
        private System.Windows.Forms.ToolTip toolTipListBox;
        private System.Windows.Forms.ListBox listBoxHours;
        private System.Windows.Forms.TextBox textBoxAverage;
        private System.Windows.Forms.TextBox textBoxMidExtreme;
        private System.Windows.Forms.TextBox textBoxRange;
    }
}

